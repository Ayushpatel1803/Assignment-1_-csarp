﻿public class Student1
{
    public int Id { get; set; }
    public StudentType Type { get; set; }
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
}

public class Student
{
    public int Id { get; private set; }
    public StudentType Type { get; private set; }
    public string? FirstName { get; private set; }
    public string? LastName { get; private set; }

    
    public static Student CreateStudent(string id, StudentType type, string firstName, string lastName)
    {
        if (id == null)
            id = "0";
        if (firstName == null)
            firstName = "Unknown";
        if (lastName == null)
            lastName = "";

        return new Student
        {
            Id = int.Parse(id),
            Type = type,
            FirstName = firstName,
            LastName = lastName
        };
    }

  
    public static void OutputStudent(Student student)
    {
        Console.WriteLine($"Student: {student.Id:D3} {student.FirstName} {student.LastName} ({student.Type})");
    }
}
