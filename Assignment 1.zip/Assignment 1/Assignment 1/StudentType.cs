﻿
public enum StudentType
{
    Unknown,
    PartTime,
    FullTime
}
