﻿
public class StudentBase
{
}