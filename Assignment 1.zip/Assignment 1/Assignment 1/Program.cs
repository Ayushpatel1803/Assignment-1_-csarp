﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        var student1 = Student.CreateStudent("001", StudentType.FullTime, "John", "Anderson");
        var student2 = Student.CreateStudent("002", StudentType.FullTime, "Karen", "Smith");
        var student3 = Student.CreateStudent("003", StudentType.PartTime, "Kevin", "Peters");

        
        Console.WriteLine("Assignment One");

        
        Student.OutputStudent(student1);
        Student.OutputStudent(student2);
        Student.OutputStudent(student3);
    }
}
